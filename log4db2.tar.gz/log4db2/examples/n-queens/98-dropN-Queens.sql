--#SET TERMINATOR @

-- Drops procedures to solve the n-queens problem.
--
-- Author: Andres Gomez
-- Version: 20220529

DROP PROCEDURE N_QUEENS@
DROP PROCEDURE SOLVE_N_QUEENS@
DROP FUNCTION IS_SAFE@

