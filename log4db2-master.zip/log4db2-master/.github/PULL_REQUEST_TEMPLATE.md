List of fixes:

 * ...
 
New features proposed in this pull request:
 
  * ...
  
Author: @yourGitHubUser
