#!/bin/bash

apt-get -y install libaio1 ksh libstdc++6-4.4-pic libstdc++6-4.4-dev libstdc++5 rpm libpam0g:i386 numactl

